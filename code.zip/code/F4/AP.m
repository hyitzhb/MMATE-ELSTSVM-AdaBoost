clc;
clear all;
close all;

% 获取所有的 .csv 文件
% csvFiles = dir('dataset\A\*.csv');

csvFiles = dir('dataset\P\*.csv');

% 所有文件并进行处理
for i = 1:length(csvFiles)
    % 读取数据
    tableData = readtable(fullfile(csvFiles(i).folder, csvFiles(i).name));
    data = tableData.Value;
%将音频数据转换成采样点数向量
    n_samples = length(data); 
    % 绘制去噪前波形图 
    figure;
    subplot(2, 1, 1);
    plot(1:n_samples, data);
    xlabel('Sampling point');
    ylabel('Amplitude');
    title('Original data');

%小波去噪参数设置
    wname = 'db10'; % 小波基选择 db10 小波
    n = 11; % 分解层数
    K = 5; % 最小值选取个数

    % 分段处理
    N = length(data);%计算数据长度
    seg_length = ceil(N/n); % 计算每段的长度
    max_modular = zeros(n,1);%生成n行1列的0向量
    for j = 1:n
        % 取出当前段的数据
        seg_start = (j-1)*seg_length+1;%数据开始索引
        seg_end = min(j*seg_length, N);%数据结束索引
        seg_data = data(seg_start:seg_end);

        % 小波分解
        [C, L] = wavedec(seg_data, n, wname);
                
        % 计算小波系数的模极大值
        max_modular(j) = max(abs(C));

    end

    % 找出最小的 K 个模极大值
    [~, min_indices] = mink(max_modular, K);%最小的K个模极大值对应的索引

    % 计算对应信号方差的方差
    variances = zeros(K, 1);
    for j = 1:K
        seg_start = (min_indices(j)-1)*seg_length+1;%模极大值对应的数据开始索引
        seg_end = min(min_indices(j)*seg_length, N);%模极大值对应的数据结束索引
        seg_data = data(seg_start:seg_end);
        variances(j) = var(seg_data);%计算方差
    end

    % 找出方差最小的模极大值
    [~, min_index] = min(variances);
    lambda = max_modular(min_indices(min_index));

    % 小波去噪
    [thr, sorh, keepapp, crit] = ddencmp('den', 'wp',data);
    [data_denoised, ~, ~, ~] = wpdencmp(data,sorh, n, wname, crit, lambda, keepapp);

    % 绘制去噪后波形图
    subplot(2, 1, 2);
    plot(1:n_samples, data_denoised);
    xlabel('Sampling point');
    ylabel('Amplitude');
    title('Denoised data');

end

