clc;
clear all;
close all;


% 获取所有的 .raw 文件
rawFiles = dir('dataset\H\*.raw');

% 所有文件并进行处理
for i = 1:length(rawFiles)
    % 读取 raw 数据
    filePath = fullfile(rawFiles(i).folder, rawFiles(i).name);
    fileID = fopen(filePath, 'r');
    data = fread(fileID, inf, 'int32');
    fclose(fileID);

    % 将音频数据转换成采样点数向量
    n_samples = length(data);
 
    % 绘制去噪前波形图 
    figure;
    subplot(2, 1, 1);
    plot(1:n_samples, data);
    xlabel('Sampling point');
    ylabel('Amplitude');
    title('Original data');

    % 小波去噪参数设置
    wname = 'db10'; % 小波基选择 db10 小波
    n = 12; % 分解层数

    % 进行小波分解
    [C, L] = wavedec(data, n, wname);

    % 选择阈值，可以根据实际情况调整
    threshold = 0.15 * max(abs(C));

    % 对小波系数进行软阈值处理
    C_denoised = wthresh(C, 'h', threshold);

    % 进行小波重构
    data_denoised = waverec(C_denoised, L, wname);

    % 绘制去噪后波形图
    subplot(2, 1, 2);
    plot(1:n_samples, data_denoised);
    xlabel('Sampling point');
    ylabel('Amplitude');
    title('Denoised data');

end

