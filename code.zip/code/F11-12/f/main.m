clc;
clear;
close all;
addpath addpath_svm
data = xlsread(['f.xlsx']);
input = data(:, 1:end-1);
output = data(:, end);

%% 数据集划分与归一化
p = round(size(data, 1) * 0.8);
train_wine = input(1:p, :);
test_wine = input(p+1:end, :);
Y = output(1:p, :);
Ytest = output(p+1:end, :);


[mtrain, ntrain] = size(train_wine);
[mtest, ntest] = size(test_wine);
dataset = [train_wine; test_wine];

[dataset_scale, ps] = mapminmax(dataset', 0, 1);
dataset_scale = dataset_scale';
X = dataset_scale(1:mtrain, :);
Xtest = dataset_scale((mtrain+1):(mtrain+mtest), :);



%% Adaboost训练
Classifiers=1;  % 弱分类器数目
[ada_train_out,ada_out]= adaboost(X,Y, Xtest,Ytest,Classifiers);  % 统计每一次的强分类器结果

%% 作图
[output_test,index]=sort(Ytest);
pre_ada=ada_out(index);
acc_ada=sum(pre_ada==output_test)./length(output_test);

[output_train,index]=sort(Y);
pre_ada_train=ada_train_out(index);
acc_ada_train=sum(pre_ada_train==output_train)./length(output_train);

figure;
hold on;
stem(output_test,'o');
plot(pre_ada,'r*');
legend('Real label','Predicted label')
xlabel('Samples','FontSize',12)
ylabel('Class label','FontSize',12)
% line1=(['Adaboost-POA-SVM  ','准确率：',num2str((acc_ada)*100),'%']);
% title({line1},'FontSize',12);
xlim([1 length(output_test)])
grid on;

figure;
hold on;
stem(output_train,'o');
plot(pre_ada_train,'r*');
legend('Real label','Predicted label')
xlabel('Samples','FontSize',12)
ylabel('Class label','FontSize',12)
% line1=(['Adaboost-POA-SVM   ','准确率：',num2str((acc_ada_train)*100),'%']);
% title({line1},'FontSize',12);
xlim([1 length(output_train)])
grid on;

%%  混淆矩阵
figure
cm = confusionchart(Ytest, ada_out);
cm.Title = 'Confusion Matrix for Test Data';
cm.ColumnSummary = 'column-normalized';
cm.RowSummary = 'row-normalized';
xlabel('Predicted label')
ylabel('Real label')
% 计算特异性和灵敏度
specificities = zeros(1, 5);  % 存储每个类别的特异性
sensitivities = zeros(1, 5);  % 存储每个类别的灵敏度

for i = 1:5
    % 计算特异性
    TN = sum(sum(cm.NormalizedValues)) - sum(cm.NormalizedValues(i, :));  % 所有元素的和减去第i行的和即为真负例
    FP = sum(cm.NormalizedValues(i, :)) - cm.NormalizedValues(i, i);  % 第i行的和减去对角线上的元素即为假正例
    specificities(i) = TN / (TN + FP);
    
    % 计算灵敏度
    TP = cm.NormalizedValues(i, i);  % 对角线上的元素即为真正例
    FN = sum(cm.NormalizedValues(:, i)) - TP;  % 第i列的和减去对角线上的元素即为假负例
    sensitivities(i) = TP / (TP + FN);
end

average_specificity = mean(specificities);  % 平均特异性
average_sensitivity = mean(sensitivities);  % 平均灵敏度

disp(['Average Specificity: ', num2str(average_specificity)]);
disp(['Average Sensitivity: ', num2str(average_sensitivity)]);



