function [predict_test,predict_train]=svm(train_wine,train_wine_labels,test_wine,test_wine_labels)

model_svm = svmtrain(train_wine_labels,train_wine);
[predict_train,~,~] = svmpredict(train_wine_labels,train_wine,model_svm);   
[predict_test,~,~] = svmpredict(test_wine_labels,test_wine,model_svm); 