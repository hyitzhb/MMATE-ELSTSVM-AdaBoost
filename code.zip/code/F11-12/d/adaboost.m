function [T_sim1 T_sim2]= adaboost(Xtrain,Ytrain, Xtest,Ytest,Classifiers)

N=size(Xtrain,1);    % 训练样本个数
M=size(Xtest,1);    % 训练样本个数

D=ones(1, N) / N;   % 样本权重
R=length(unique(Ytrain)); % 样本类别
d_error = 0.1;            % 误差阈值

for T=1:Classifiers  % 对每个弱分类器逐次建模

    [predict_test,predict_train]=svm_ada(Xtrain,Xtest,Ytrain,Ytest);  % 注意，此时的X/Y不同于原始的Xtrain/Ttrain
    t_sim1{T}=predict_train;  % 保存每个弱分类器的结果：训练集预测结果
    t_sim2{T}=predict_test;   % 测试集预测结果
    Error(T, :) = (abs(t_sim1{T} - predict_train)) / R;
    
    %%  调整D值
    weight(T) = 0;
    for j = 1 : N
        if abs(Error(T, j)) > d_error
            weight(T) = weight(T) + D(T, j);
            D(T + 1, j) = D(T, j) * 1.1;
        else
            D(T + 1, j) = D(T, j);
        end
    end
    
    %%  弱分类器i权重
    weight(T) = 0.5 / exp(abs(weight(T)));
    
    %%  D值归一化
    D(T + 1, :) = D(T + 1, :) / sum(D(T + 1, :));
end

%%  强预测器预测
weight = weight / sum(weight);

%%  强分类器分类结果
T_sim1 = zeros(N,1);
T_sim2 = zeros(M,1);

for i = 1 : Classifiers
    output1 = (weight(i) * t_sim1{i});
    output2 = (weight(i) * t_sim2{i});
    
    T_sim1 = (output1 + T_sim1);
    T_sim2 = (output2 + T_sim2);
end
T_sim1=round(T_sim1);
T_sim2=round(T_sim2);



