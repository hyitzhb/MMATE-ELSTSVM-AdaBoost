function [predict_test,predict_train]=svm_ada(train_wine,test_wine,train_wine_labels,test_wine_labels)
%%  待优化参数信息
dim=2;              % 待优化参数个数，c和g
ub=[500 100];       % 参数取值上界
lb=[0.0001 0.0001]; % 参数取值下界
fobj=@(x)fun(x,train_wine_labels,train_wine,test_wine_labels,test_wine);
N=20;          % 种群大小
Max_iter=30;  % 迭代数

%% 迭代计算
[~,best_p,fbest_store,X]=POA(N,Max_iter,lb,ub,dim,fobj); 

%% 利用最佳的参数进行SVM网络训练
cmd_svm = ['-c ',num2str(best_p(1)),' -g ',num2str(best_p(2))];
model_svm = svmtrain(train_wine_labels,train_wine,cmd_svm);

%% SVM网络预测
[predict_train,~,~] = svmpredict(train_wine_labels,train_wine,model_svm);   
[predict_test,~,~] = svmpredict(test_wine_labels,test_wine,model_svm); 
fitness_train=sum(predict_train==train_wine_labels)./length(train_wine_labels);
fitness_test=sum(predict_test==test_wine_labels)./length(test_wine_labels);
end
