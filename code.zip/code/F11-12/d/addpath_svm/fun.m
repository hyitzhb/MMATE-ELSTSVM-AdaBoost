function fitness=fun(x,train_label,train_in,test_label,test_in)
cmd = [' -c ',num2str(x(1)),' -g ',num2str( x(2) ),' -v ',num2str(5)];
fitness = svmtrain(train_label, train_in, cmd);
fitness=100-fitness;
end