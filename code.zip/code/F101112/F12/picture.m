clc;
clear;
close all;
% 读取Excel文件中的数据
data = xlsread('3.xlsx'); % 假设数据在第一个工作表的第一列
load ada_out.mat;
load output_test.mat;
load pre_ada.mat;
load Ytest.mat
% 提取第一列的数据
columnData = data(:, 1);

% 绘制折线图
figure; % 创建一个新的图形窗口
plot(columnData, 'LineWidth', 1.5); % 绘制折线图
xlabel(['Number of weak learners']); % X轴标签
ylabel('Resubstitution loss'); % Y轴标签
grid on; % 显示网格

figure;
hold on;
stem(output_test,'o');
plot(pre_ada,'r*');
xlabel('Samples','FontSize',12);
ylabel('Class label','FontSize',12);
legend('Real label','Predicted label');
xlim([1 length(output_test)])
grid on;

figure
cm = confusionchart(Ytest, ada_out);
cm.Title = 'Confusion Matrix for Test Data';
cm.ColumnSummary = 'column-normalized';
cm.RowSummary = 'row-normalized';
xlabel('Predicted label')
ylabel('Real label')
