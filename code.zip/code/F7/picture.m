% 指定xlsx文件路径
xlsxFilePath = 'F9b.xlsx';   % 'F9a.xlsx'  'F9b.xlsx'  

% 从xlsx文件中读取数据
data = xlsread(xlsxFilePath);

% 获取数据的行数和列数
[numRows, numCols] = size(data);

% 绘制每一行的连线图
figure;
hold on;

for i = 1:numRows
    % 提取当前行的数据
    row_data = data(i, :);

    % 绘制连线图
    plot(row_data, '.-', 'DisplayName', ['Category ', num2str(i)]);
end

hold off;

% 添加图例
legend('circumferential crack', 'longitudinal crack', 'gasket leak', 'orifice leak', 'no leak');
xlabel('Scales');
ylabel('MATE values');

